/*
  Team 01 -- The Cool Kids
  APCS1 pd8
  HW10 -- Mo Money Mo Problems 
  2017-10-03 T
*/

public class BankAccount
{
    //instance variables
    private String name;
    private String passwd;
    private int pin;
    private int acctNum;
    private double balance;

    //mutators
    
    /* Set Name Mutator: initializes instance vars to default vals
       precondition:  a string parameter is passed through
       postcondition: instance vars have appropriate default vals
       ````````````````````````````````````````````````````*/
    
    public String setName(String newName)
    // changes value of name to newName and returns newName using the variable oldName
    {
	String oldName = name;
	name = newName;
	return oldName;
	
    }


    
    /* Set Password Mutator: initializes instance vars to default vals
       precondition:  a string parameter is passed through
       postcondition: instance vars have appropriate default vals
       ````````````````````````````````````````````````````*/
    
    public String setPasswd(String newPasswd)
    // changes value of passwd to newPasswd and returns newPasswd using the variable oldPasswd
    {
	String oldPasswd = passwd;
	passwd = newPasswd;
	return oldPasswd;
    }


    
    /* Set Pin Mutator: initializes instance vars to default vals based on 2 conditions
       precondition:  a int parameter is passed through
       postcondition: instance vars have appropriate default vals or error is returned and var set to a default val
       ````````````````````````````````````````````````````*/
    
    public int setPin(int newPin)
    //If pin is between 10000 and 9998, changes value of pin to newPin and returns the old pin.
    //Otherwise sets value of pin to 9999, returns an error message, and returns the old pin
    {
	if (newPin >= 1000 && newPin <= 9998) {
	    int oldPin = pin;
	    pin = newPin;
	    return oldPin;
	}
	else {
	    int oldPin = pin;
	    pin = 9999;
	    System.out.println("BAD BAD PIN! NUMBER NOT IN PROPER RANGE!");
	    return oldPin;
	}
    }


    
    /* Set Acct Number Mutator: initializes instance vars to default vals based on 2 conditions
       precondition:  a int parameter is passed through
       postcondition: instance vars have appropriate default vals or error is returned and var is set to a default val
       ````````````````````````````````````````````````````*/
    
    public int setAcctNum(int newAcctNum)
    // If acctNum is between 100000000 and 999999998, changes the value of acctNum to newAcctNum and returns the old acctNum.
    // Otherwise sets the value of acctNum to 999999999, returns an error message, and returns the old acctNum
    {
	if (newAcctNum >= 100000000 && newAcctNum <= 999999998) {
	    int oldAcctNum = acctNum;
	    acctNum = newAcctNum;
	    return oldAcctNum;
	}
	else {
	    int oldAcctNum = acctNum;
	    acctNum = 999999999;
	    System.out.println("BAD BAD ACCOUNT NUMBER! NUMBER NOT IN PROPER RANGE!");
	    return oldAcctNum;
	}
    }


    
    /* Set Balance Mutator : initializes instance vars to default vals
       precondition:  a double parameter is passed through
       postcondition: instance vars have appropriate default vals
       ````````````````````````````````````````````````````*/
    
    public double setBalance(double newBalance)
    // sets the value of balance to newBalane and returns the old one
    {
	double oldBalance = balance;
	balance = newBalance;
	return oldBalance;
    }


    
    /* Deposit Mutator: overwrites the original deposit var
       precondition:  a double parameter is passed through
       postcondition: balance is changed
       ````````````````````````````````````````````````````*/
    
    public void deposit(double depositAmount) {
	// adds the amount depositAmount to the current balance
	balance = balance + depositAmount;
    }


    
    /* Withdraw Mutator: overwrites the original deposit var based in a condition
       precondition:  a double parameter is passed through
       postcondition: balance is changed or an error is returned and the the var is not overwritten. Returns a bool based on success.
       ````````````````````````````````````````````````````*/
    
    public boolean withdraw(double withdrawAmount) {
	//Subtracts the amount withdrawAmount from the current balance and returns true if the amount is not greater than the current balance.
	//Otherwise, prints an error message and return false.
	if (withdrawAmount > balance) {
	    System.out.println("YOU'RE TOO BROKE! GET MORE RICH!");
	    return false;
	}
	else {
	    balance -= withdrawAmount;
	    return true;
	}
    }


    
    /* Authenticate  Mutator: checks if parameters match w/ vars and returns a bool.
       precondition: a int and a string parameter is passed through
       postcondition: returns a bool
       ````````````````````````````````````````````````````*/
    
    public boolean authIdentity(int testAcctNum, String testPasswd) {
	// checks to see if the entered passwd matches the entered acctNum
	return (acctNum == testAcctNum && testPasswd == passwd);
    }

    //overwritten toString()
    public String toString() {
	String retStr = "\nAccount info:\n=======================";
	retStr = retStr + "\nName: " + name;
	retStr = retStr + "\nPassword: " + passwd;
	retStr = retStr + "\nPIN: " + pin;
	retStr = retStr + "\nAccount Number: " + acctNum;
	retStr = retStr + "\nBalance: " + balance;
	retStr = retStr + "\n=======================";
	return retStr;
    }

    
    /* default constructor: initializes instance vars to default vals
       precondition:  none
       postcondition: instance vars have appropriate default vals
       ````````````````````````````````````````````````````*/
    public BankAccount() {
	name = "Mr.Brown";
	passwd = "cs";
	pin = 1234;
	acctNum = 123456789;
	balance = 1000;

    }//end default constructor


    /* overloaded constructor: allows caller to specify account 
       number and passwd. Assigns defaults
       to other instance vars.
       precondition:  params are passed in specified order
       postcondition: instance vars have values specified by params
       ````````````````````````````````````````````````````*/
    public BankAccount( int newAcctNum, String newPass ) {
       	name = "Mr.Brown";
	passwd = newPass;
	pin = 1234;
	acctNum = newAcctNum;
	balance = 1000;
    }


    
    /* overloaded constructor: allows caller to specify instance vars
       precondition:  params are passed in specified order
       postcondition: instance vars have values specified by params
       ````````````````````````````````````````````````````*/
    public BankAccount( int newAcctNum, String newPass, 
			double newBal, String newName, int newPin ) {
      	name = newName;
	passwd = newPass;
	pin = newPin;
	acctNum = newAcctNum;
	balance = newBal;


    }
    

    /*
    //main method for testing
    public static void main(String[] args)
    {
	// INSERT METHOD CALLS FOR TESTING HERE
	//BankAccount bop = new BankAccount();
	System.out.println(bop.setName("Mr.Brown"));
	System.out.println(bop.setPasswd("cs!"));
	System.out.println(bop.setPin(1234));
	System.out.println(bop.setAcctNum(123456789));
	System.out.println(bop.setBalance(0));
	bop.deposit(20);
	bop.withdraw(10);
	System.out.println(bop.toString());
    } //end main()    
*/
} //end class BankAccount
