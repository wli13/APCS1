// Wenting Li
// APCS1 pd08
// HW11 -- Breaking the Bank
// 2017-10-04 
// Team BEC ---- Larry Wong, John Liu, Wenting Li
// Reviewing Team 1

public class Teller{
    
    public static void main(String [] args )
    {
	
	// Instance Vars
	String info;

	//Testing default constructor
	BankAccount Bob = new BankAccount();
	System.out.println("-===========Testing All Functions===========-");
	System.out.println("");
	info = Bob.toString();
	System.out.println("==============Default Information===============");
	System.out.println(info);
	System.out.println("");

	
	System.out.println("==========Testing Deposit==========");
	System.out.print("Depositing 100......");
	Bob.deposit(100);
	System.out.println(Bob.toString());
	System.out.println("");

	
	System.out.println("==========Testing Withdraw==========");
	System.out.print("Withdrawing 100......");
	Bob.withdraw(100);
	System.out.println(Bob.toString());
	System.out.println("");
	System.out.print("Withdrawing 10000......");
	Bob.withdraw(10000);
	System.out.println("");

	
	System.out.println("=========Testing Authenticate=========");
	System.out.println("--Entering Correct info:  Acct#: 123456789 Passwd: cs--");
	if (Bob.authIdentity(123456789,"cs")){
	System.out.println("Success");
	}
	
	System.out.println("");
	
	System.out.println("--Entering Incorrect info:  Acct#: 111111111 Passwd: ap--");
	if (! Bob.authIdentity(11111111,"ap")){
	System.out.println("Failure") ;
	}
	System.out.println("");
	



	//Testing constructor w/ Acct# & Pass input
	System.out.println("");
	System.out.println("");
	System.out.println("Setting newAcct#: 234567891 and newPasswd: Cool");
	BankAccount Tom = new BankAccount(234567891, "Cool");
	System.out.println(Tom.toString());



	//Testing constructor w/ all inputs
	System.out.println("");
	System.out.println("");
	System.out.println("Setting newAcct#: 11111111, newPasswd: fly, newBal: 2323, newName: Jerry, newPin: 9090");
	BankAccount Jerry = new BankAccount(111111111, "fly", 2323, "Jerry", 9090);
	System.out.println(Jerry.toString());
	
    }






}//end teller class
